public class Exercise01_10 {
  public static void main(String[] args) {
    System.out.println((14 / 45.5) * 60 / 1.6);
  }
}
