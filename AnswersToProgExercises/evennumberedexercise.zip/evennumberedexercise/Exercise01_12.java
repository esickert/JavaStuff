public class Exercise01_12 {
  public static void main(String[] args) {
    System.out.println(24 / (1 + (40 + 35.0 / 60) / 60) * 1.6);
  }
}
